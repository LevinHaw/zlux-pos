// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'splash_viewmodel.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$splashViewModelHash() => r'0ae2caa8d4f629c87fbe17c827c25b71b3588646';

/// See also [SplashViewModel].
@ProviderFor(SplashViewModel)
final splashViewModelProvider = AutoDisposeAsyncNotifierProvider<
  SplashViewModel,
  SplashDestination
>.internal(
  SplashViewModel.new,
  name: r'splashViewModelProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$splashViewModelHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SplashViewModel = AutoDisposeAsyncNotifier<SplashDestination>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
