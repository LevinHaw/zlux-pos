// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'login_viewmodel.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$loginViewModelHash() => r'8f4aff3aadc41e4b00e01842b4e9eba85e936d12';

/// See also [LoginViewModel].
@ProviderFor(LoginViewModel)
final loginViewModelProvider =
    AutoDisposeAsyncNotifierProvider<LoginViewModel, UserEntity?>.internal(
      LoginViewModel.new,
      name: r'loginViewModelProvider',
      debugGetCreateSourceHash:
          const bool.fromEnvironment('dart.vm.product')
              ? null
              : _$loginViewModelHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$LoginViewModel = AutoDisposeAsyncNotifier<UserEntity?>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
