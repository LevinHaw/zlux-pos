import 'package:drift/drift.dart';

import '../app_database.dart';
import '../table/income_entries_table.dart';

part 'income_entry_dao.g.dart';

@DriftAccessor(tables: [IncomeEntries])
class IncomeEntryDao extends DatabaseAccessor<AppDatabase>
    with _$IncomeEntryDaoMixin {
  IncomeEntryDao(super.db);

  Stream<List<IncomeEntryData>> watchIncomeEntries(String ownerId) {
    final query = select(incomeEntries)
      ..where(
        (e) => e.ownerId.equals(ownerId) & e.isDeleted.equals(false),
      )
      ..orderBy([(e) => OrderingTerm.desc(e.date)]);
    return query.watch();
  }

  Future<IncomeEntryData?> getIncomeEntry(String id) {
    return (select(incomeEntries)..where((e) => e.id.equals(id)))
        .getSingleOrNull();
  }

  Future<void> upsertIncomeEntry(IncomeEntriesCompanion entry) {
    return into(incomeEntries).insertOnConflictUpdate(entry);
  }

  Future<void> upsertAllIncomeEntries(List<IncomeEntriesCompanion> entries) {
    return batch((b) {
      b.insertAllOnConflictUpdate(incomeEntries, entries);
    });
  }

  Future<void> deleteIncomeEntry(String id) {
    return (update(incomeEntries)..where((e) => e.id.equals(id))).write(
      IncomeEntriesCompanion(
        isDeleted: const Value(true),
        isSynced: const Value(false),
      ),
    );
  }

  Future<List<IncomeEntryData>> getUnsyncedIncomeEntries(String ownerId) {
    return (select(incomeEntries)
          ..where(
            (e) => e.ownerId.equals(ownerId) & e.isSynced.equals(false),
          ))
        .get();
  }

  Future<void> markSynced(String id) {
    return (update(incomeEntries)..where((e) => e.id.equals(id)))
        .write(const IncomeEntriesCompanion(isSynced: Value(true)));
  }
}
