// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'income_dao.dart';

// ignore_for_file: type=lint
mixin _$IncomeDaoMixin on DatabaseAccessor<AppDatabase> {
  $IncomeTable get income => attachedDatabase.income;
}
